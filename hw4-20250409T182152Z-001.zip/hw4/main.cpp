#include <iostream>
#include <queue>
#include <vector>
#include <string>

using namespace std;

struct line {
    line* right;
    line* left;
    int p;
    string command;
    string data;

    line() : right(nullptr), left(nullptr), p(0) {}

    bool operator>(const line& other) const {
        return p > other.p; 
    }
}

//helper functions
void rosa_park() {

}



void read_input_and_init_queue(string inputFile, prioty_queue<line, vector<line>, greater<line>>& q1, queue<line>& q2) {
    
    //open the input file
    ifstream input(inputFile);
    if (!input) {
        cerr << "Error opening input file." << endl;
        return;
    }
    //find amount of lines in the input file
    int lines = 0;
    //for each line in the input file construct a line object and push it into the priority queue
        //if the line has BST, look at the last line in the file and construct a line object with line->command = lastline 
        //and push it into the priotrity queue

        //if the line has ADD, REMOVE, REPLACE, SWAP, DECODE, BST. Construct a line object and push it into the priority queue

}

void process_queues(string outputFile, prioty_queue<line, vector<line>, greater<line>>& pq, queue<line>& mq) {
    //open the output file
    ofstream output(outputFile);
    if (!output) {
        cerr << "Error opening output file." << endl;
        return;
    }
    while(!q1.empty()) {
    //line* priority_top = pq.top()
    //line* queue_top = mq.top()
    
        //if priority_top.line->command == "ADD"
            if (q2.empty()) {
                q1.pop();
            } else {
                //char marker = priority_top.line->data[0]
                //char add = priority_top.line->data[2] 
                //for loop char c : queue_top.line->data
                    //if c == marker
                        //add the add character after the marker
                
                //q1.pop();
            }


        //if priority_top.line->command == "REMOVE"
            if (mq.empty()) {
                pq.pop();
            } else {
                //char remove = priority_top.line->data
                //for char c : queue_top.line->data
                    //if c == remove
                        //erase c from the string
            }

        //if priority_top.line->command == "REPLACE"
            if (mq.empty()) {
                pq.pop();
            } else {
                //char marker = priority_top.line->data[0]
                //char replacement = priority_top.line->data[2]
                //for char c : queue_top.line->data
                    //if c == marker
                        //queue_top.line->data[it] = replacement
                
                //move rosaparks(queue_top)
            }

        //if priioline->command == "BST"
            //pop the line from the queue and push it into the queue q2
            //if the line has BST, look at the last line in the file and construct a line object with line->command = lastline 
            //and push it into the priotrity queue

        //if line->command == "SWAP"

        //if line->command == "DECODE"
    }

}


int main(int argc, char* argv[]) {
    ArgumentManager am(argc, argv);
    string inputFile = am.get("input");
    string outputFile = am.get("output");

    prioty_queue<line, vector<line>, greater<line>> q1;
    queue<line> q2;
    
    return 0;
}